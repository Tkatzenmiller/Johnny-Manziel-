// Vercel serverless function: answers searches with Claude, using only the page's source library.
// Needs the environment variable ANTHROPIC_API_KEY (set it in Vercel > Project > Settings > Environment Variables).
const LIB = require("../lib/library.json");

const LIB_TEXT = LIB.map(s => `[${s.id}] ${s.outlet} (${s.date}): ${s.note}`).join("\n");
const NOTE = Object.fromEntries(LIB.map(s => [s.id, s.note]));
const MODEL_ANSWER = process.env.MODEL_ANSWER || "claude-sonnet-5-5";
const MODEL_AUDIT = process.env.MODEL_AUDIT || "claude-haiku-5-5";
const LIMIT = Number(process.env.SEARCHES_PER_10_MIN || 20); // per visitor, best effort
const hits = new Map();

const draftPrompt = q => `Answer a visitor's search on a school research page about former quarterback Johnny Manziel.
Search: """${q}"""

The question can be about anything. Answer it helpfully, accurately and directly.

SOURCE LIBRARY (reliable outlets only; each line paraphrases what that source reports):
${LIB_TEXT}

Rules:
1. Use facts from the library whenever they apply. Wikipedia lines are background; if a Wikipedia line conflicts with a news source, say so in "conflicts". Split your answer into short, separate facts. For each fact, list EVERY library id whose note states it. Never list an id whose note does not state it.
2. When the library doesn't cover something, you may use your own knowledge, but only facts you are confident are accurate and well established. Give those facts an empty ids list. Never repeat rumors, gossip, tabloid claims or speculation. If you don't know, say so.
3. If sources disagree (for example on a number), explain briefly in "conflicts"; otherwise null.
4. For anything touching suicide or self-harm, stay factual and non-graphic, give no method details, and set "support": true.
5. Plain, neutral language. "answer" is 2 to 5 sentences.
Return JSON only, in this shape:
{"answer":"...","claims":[{"text":"...","ids":[1,2,3]}],"conflicts":null,"support":false}`;

const auditPrompt = packet => `You are auditing citations. For each claim, read only the notes given for its cited sources. Keep an id only if that note clearly states the claim (same fact, and the same numbers, dates and names where the claim has them). Drop every other id. Do not add ids.
${JSON.stringify(packet)}
Return JSON only: {"results":[{"i":0,"ids":[1,2]}]}`;

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST." });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(503).json({ error: "Live answers are not set up (missing ANTHROPIC_API_KEY)." });

  const ip = String(req.headers["x-forwarded-for"] || "anon").split(",")[0].trim();
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter(t => now - t < 10 * 60 * 1000);
  if (recent.length >= LIMIT) return res.status(429).json({ error: "Too many searches. Try again in a few minutes." });
  recent.push(now); hits.set(ip, recent);

  let body = req.body || {};
  if (typeof body === "string") { try { body = JSON.parse(body); } catch { body = {}; } }

  let prompt, model, maxTokens;
  if (body.kind === "answer") {
    const q = String(body.question || "").replace(/\s+/g, " ").trim().slice(0, 300);
    if (q.length < 2) return res.status(400).json({ error: "Question is too short." });
    prompt = draftPrompt(q); model = MODEL_ANSWER; maxTokens = 1500;
  } else if (body.kind === "audit") {
    // Notes always come from the server's library, never from the browser.
    const packet = (Array.isArray(body.packet) ? body.packet : []).slice(0, 12).map(p => ({
      i: Number(p.i),
      claim: String(p.claim || "").slice(0, 400),
      sources: (Array.isArray(p.sources) ? p.sources : []).slice(0, 15)
        .map(s => ({ id: Number(s.id), note: NOTE[Number(s.id)] })).filter(s => s.note)
    })).filter(p => p.sources.length);
    if (!packet.length) return res.status(200).json({ results: [] });
    prompt = auditPrompt(packet); model = MODEL_AUDIT; maxTokens = 600;
  } else {
    return res.status(400).json({ error: "Unknown request." });
  }

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model, max_tokens: maxTokens, messages: [{ role: "user", content: prompt }] })
    });
    if (r.status === 429) return res.status(429).json({ error: "Claude is busy. Try again in a minute." });
    if (!r.ok) {
      const detail = await r.text();
      console.error("Anthropic API error", r.status, detail.slice(0, 500));
      return res.status(502).json({ error: "The answer service returned an error." });
    }
    const data = await r.json();
    const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) return res.status(502).json({ error: "Couldn't read the answer." });
    return res.status(200).json(JSON.parse(m[0]));
  } catch (err) {
    console.error(err);
    return res.status(502).json({ error: "The answer service couldn't be reached." });
  }
};
